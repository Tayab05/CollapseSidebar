import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Collapsible Sidebar',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false, // Add this line to hide the debug banner
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isCollapsed = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Collapsible Sidebar',
          textAlign: TextAlign.center, // Align the text in the center
        ),
        centerTitle: true, // Center the title horizontally
      ),
      body: Stack(
        children: <Widget>[
          _buildSidebar(),
          _buildMainContent(),
        ],
      ),
    );
  }

  Widget _buildSidebar() {
    return Container(
      color: Colors.blue,
      width: _isCollapsed ? 60 : 200,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          SizedBox(height: 50),
          _buildSidebarItem(Icons.home, 'Home'),
          _buildSidebarItem(Icons.settings, 'Settings'),
          _buildSidebarItem(Icons.question_answer, 'Ask a Question'),
          _buildSidebarItem(Icons.logout, 'Logout'),
        ],
      ),
    );
  }

  Widget _buildSidebarItem(IconData icon, String label) {
    return Row(
      children: <Widget>[
        SizedBox(width: _isCollapsed ? 10 : 20),
        Icon(icon, color: Colors.white),
        SizedBox(width: 10),
        _isCollapsed
            ? Container()
            : Text(
          label,
          style: TextStyle(color: Colors.white),
        ),
      ],
    );
  }


  Widget _buildMainContent() {
    return Container(
      margin: EdgeInsets.only(left: _isCollapsed ? 60 : 200),
      child: Center(
        child: ElevatedButton(
          onPressed: () {
            setState(() {
              _isCollapsed = !_isCollapsed;
            });
          },
          child: Text(
            _isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar',
            style: TextStyle(color: Colors.white),
          ),
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
          ),
        ),
      ),
    );
  }
}
